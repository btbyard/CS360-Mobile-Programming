package com.zybooks.weighttrakker3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class WeightHistory extends AppCompatActivity {

    private Button homeButton;
    private TextView currentWeightDisplay;
    private String currentWeight;
    private String goalWeight;
    private TextView goalWeightDisplay;
    private TextView historyGoalWeight;
    private TextView historyCurrentWeight;
    Button insert, update, delete, view;
    EditText weight, date;
    DBHelper2 DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_history);


        homeButton = findViewById(R.id.button5);
        historyCurrentWeight = findViewById(R.id.textView43);
        historyGoalWeight = findViewById(R.id.textView46);
        weight = findViewById(R.id.editTextWeight);
        date = findViewById(R.id.editTextDate);
        insert = findViewById(R.id.button7);
        update = findViewById(R.id.button3);
        delete = findViewById(R.id.button6);
        view = findViewById(R.id.button8);
        DB = new DBHelper2(this);


        currentWeight = getIntent().getExtras().getString("passedCurrentWeight");
        historyCurrentWeight.setText(currentWeight);
        goalWeight = getIntent().getExtras().getString("passedGoalWeight");
        historyGoalWeight.setText(goalWeight);


        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightTXT = weight.getText().toString();
                String dateTXT = date.getText().toString();

                Boolean checkinsertdata = DB.insertuserdata(weightTXT, dateTXT);
                if(checkinsertdata==true)
                    Toast.makeText(WeightHistory.this, "New Entry Added", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(WeightHistory.this, "New Entry Not Added", Toast.LENGTH_SHORT).show();

            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightTXT = weight.getText().toString();
                String dateTXT = date.getText().toString();

                Boolean checkupdatedata = DB.updateuserdata(weightTXT, dateTXT);
                if(checkupdatedata==true)
                    Toast.makeText(WeightHistory.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(WeightHistory.this, "Entry Not Updated", Toast.LENGTH_SHORT).show();

            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightTXT = weight.getText().toString();

                Boolean checkdeletedata = DB.deletedata(weightTXT);
                if(checkdeletedata==true)
                    Toast.makeText(WeightHistory.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(WeightHistory.this, "Entry Not Deleted", Toast.LENGTH_SHORT).show();

            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = DB.getdata();
                if(res.getCount()==0){
                    Toast.makeText(WeightHistory.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("Weight :"+res.getString(0)+"\n");
                    buffer.append("Date :"+res.getString(1)+"\n\n");
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(WeightHistory.this);
                builder.setCancelable(true);
                builder.setTitle("Previous Weight Entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });


        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(WeightHistory.this, HomeScreen.class);
                intent.putExtra("passedGoalWeight", goalWeight);
                intent.putExtra("passedCurrentWeight", currentWeight);
                startActivity(intent);
            }
        });
    }
}