package com.zybooks.weighttrakker3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.lang.Object;

import java.util.Set;

public class EnterWeight extends AppCompatActivity {

    private Button homeButton2;
    private Button setGoalWeight;
    public TextView displayGoalWeight;
    public EditText userWeight;
    private TextView currentWeightDisplay;
    public String currentWeight;
    public String goalWeight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_weight);


        //homeButton2 = findViewById(R.id.button6);
        setGoalWeight = findViewById(R.id.button12);
        displayGoalWeight = findViewById(R.id.textView42);
        userWeight = findViewById(R.id.goalWeightText);
        currentWeightDisplay = findViewById(R.id.textView15);

        currentWeight = getIntent().getExtras().getString("passedCurrentWeight");
        currentWeightDisplay.setText(currentWeight);

        setGoalWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String GoalWeightStored = userWeight.getText().toString();
                displayGoalWeight.setText(GoalWeightStored);
                Intent i = new Intent(EnterWeight.this, HomeScreen.class);
                goalWeight = userWeight.getText().toString();
                i.putExtra("passedGoalWeight", goalWeight);
                i.putExtra("passedCurrentWeight", currentWeight);
                startActivity(i);
                finish();
            }
        });


    }
}