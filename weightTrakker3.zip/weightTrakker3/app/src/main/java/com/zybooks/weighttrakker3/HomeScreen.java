package com.zybooks.weighttrakker3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.lang.Object;
import java.lang.Math;


public class HomeScreen extends AppCompatActivity {


    private Button editGoalWeight;
    private Button viewWeightHistory;
    private Button enterCurrentWeight;
    public Button SMSSetup;
    public TextView homeCurrentWeight;
    public String currentWeight;
    public String goalWeight;
    public TextView homeGoalWeight;
    public TextView amountUntilGoal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        editGoalWeight = findViewById(R.id.editGoalWeight);
        viewWeightHistory = findViewById(R.id.button4);
        enterCurrentWeight = findViewById(R.id.button13);
        homeCurrentWeight = findViewById(R.id.textView23);
        homeGoalWeight = findViewById(R.id.textView26);
        amountUntilGoal = findViewById(R.id.textView38);
        SMSSetup = findViewById(R.id.button9);


        currentWeight = getIntent().getExtras().getString("passedCurrentWeight");
        homeCurrentWeight.setText(currentWeight);
        goalWeight = getIntent().getExtras().getString("passedGoalWeight");
        homeGoalWeight.setText(goalWeight);


        /*if((Integer.parseInt(homeCurrentWeight.getText().toString()))!=0){
            currentWeight = getIntent().getExtras().getString("passedCurrentWeight");
            homeCurrentWeight.setText(currentWeight);
        }
        if((Integer.parseInt(homeGoalWeight.getText().toString()))!=0){
            goalWeight = getIntent().getExtras().getString("passedGoalWeight");
            homeGoalWeight.setText(goalWeight);
        }
        */

        int goalMath = Integer.parseInt(homeGoalWeight.getText().toString());
        int currentMath = Integer.parseInt(homeCurrentWeight.getText().toString());
        int answer = currentMath - goalMath;
        amountUntilGoal.setText(String.valueOf(answer) + " lbs");
        //homeGoalWeight.setText(homeGoalWeight);



        //congrats if goal weight reached
        if(answer==0){
            AlertDialog.Builder builder = new AlertDialog.Builder(HomeScreen.this);
            builder.setCancelable(true);
            builder.setTitle("          CONGRATS\n YOU REACHED GOAL WEIGHT!\n");
            builder.show();
        }


        editGoalWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeScreen.this, enter_current_weight.class);
                startActivity(intent);
            }
        });

        viewWeightHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeScreen.this, WeightHistory.class);
                intent.putExtra("passedGoalWeight", goalWeight);
                intent.putExtra("passedCurrentWeight", currentWeight);
                startActivity(intent);
            }
        });

        enterCurrentWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeScreen.this, enter_current_weight.class);
                startActivity(intent);
            }
        });

        SMSSetup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeScreen.this, SMS.class);
                startActivity(intent);
            }
        });

    }
}
