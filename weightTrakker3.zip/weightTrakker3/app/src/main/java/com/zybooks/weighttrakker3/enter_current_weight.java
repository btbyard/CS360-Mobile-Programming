package com.zybooks.weighttrakker3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class enter_current_weight extends AppCompatActivity {

    private Button homeButton3;
    private Button setWeight;
    private EditText newWeight;
    private TextView displayCurrentWeight;
    public String weight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_current_weight);

        //homeButton3 = findViewById(R.id.button15);
        setWeight = findViewById(R.id.button14);
        displayCurrentWeight = findViewById(R.id.textView20);
        newWeight = findViewById(R.id.updateWeight);

        setWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentWeightStored = newWeight.getText().toString();
                displayCurrentWeight.setText(currentWeightStored);
                Intent i = new Intent(enter_current_weight.this, EnterWeight.class);
                //Intent in = new Intent(enter_current_weight.this, HomeScreen.class);
                weight = newWeight.getText().toString();
                i.putExtra("passedCurrentWeight", weight);
                //in.putExtra("passedToHome", weight);
                startActivity(i);
                finish();
            }
        });


    }
}