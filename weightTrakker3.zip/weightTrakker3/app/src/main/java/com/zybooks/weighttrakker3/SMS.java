package com.zybooks.weighttrakker3;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SMS extends AppCompatActivity {

    private EditText number;
    private TextView message;
    private Button send, home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_m_s);

        number = findViewById(R.id.editTextnumber);
        send = findViewById(R.id.button10);
        message = findViewById(R.id.textView14);
        //home = findViewById(R.id.button11);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                    if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                        sendSMS();
                    } else {
                        requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 1);
                    }
                }
            }
        });

        /*home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SMS.this, HomeScreen.class);
                startActivity(intent);
            }

        });

         */
    }
        private void sendSMS(){
            String phoneNo = number.getText().toString().trim();
            String SMS = message.getText().toString().trim();

            try{
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, SMS, null, null);
                Toast.makeText(this, "Message Sent!", Toast.LENGTH_SHORT).show();
            } catch(Exception e){
                e.printStackTrace();
                Toast.makeText(this, "Message Send Failed", Toast.LENGTH_SHORT).show();
            }

        }


    }
