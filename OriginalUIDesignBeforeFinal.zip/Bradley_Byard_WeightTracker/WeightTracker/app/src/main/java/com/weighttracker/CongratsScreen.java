package com.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CongratsScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_congrats_screen);
    }
}